<?php
/*
	Plugin Name: HGR MegaFooter
	Plugin URI: http://highgradelab.com/
	Author: HighGrade
	Author URI: https://highgradelab.com
	Version: 1.0.0
	Description: Visual Composer based MegaFooter for HighGrade Themes.
	Text Domain: hgr
*/

/*
	If accesed directly, exit
*/
if (!defined('ABSPATH')) exit;


if(!class_exists('HGR_MEGAFOOTER')) {

	class HGR_MEGAFOOTER {
		
		/**
		* Constructor function
		* @since 1.0.0
		*/
		public function __construct(){
			
			// Add megamenu post type: hgr_megafooter
			add_action('init',array($this,'hgr_post_type'));
			
			// Init & save metaboxex for pages
			add_action( 'add_meta_boxes', array( $this, 'hgr_megafooter_metaboxes' ) );
			add_action( 'save_post', array( $this, 'hgr_save_megafooter_data' ) );
						
			// Remove Some metaboxes
			add_action( 'do_meta_boxes', array( $this, 'hgr_remove_thrdparty_meta_boxes' ) );
		}
		
		
		/**
		*	Register the post type hgr_megafooter
		*	@since 1.0.0
		*/
		function hgr_post_type() {
			register_post_type( 'hgr_megafooter',
				array(
					'labels' => array(
						'name'               => esc_html__( 'Mega Footers', 'hgr_lang' ),
						'singular_name'      => esc_html__( 'MegaFooter', 'hgr_lang' ),
						'menu_name'          => esc_html__( 'MegaFooters', 'hgr_lang' ),
						'name_admin_bar'     => esc_html__( 'MegaFooters', 'hgr_lang' ),
						'add_new'            => esc_html__( 'Add New', 'info bar', 'hgr_lang' ),
						'add_new_item'       => esc_html__( 'Add New MegaFooter', 'hgr_lang' ),
						'new_item'           => esc_html__( 'New MegaFooter', 'hgr_lang' ),
						'edit_item'          => esc_html__( 'Edit MegaFooter', 'hgr_lang' ),
						'view_item'          => esc_html__( 'View MegaFooter', 'hgr_lang' ),
						'all_items'          => esc_html__( 'All MegaFooters', 'hgr_lang' ),
						'search_items'       => esc_html__( 'Search MegaFooters', 'hgr_lang' ),
						'not_found'          => esc_html__( 'No MegaFooter found.', 'hgr_lang' ),
						'not_found_in_trash' => esc_html__( 'No MegaFooter found in Trash.', 'hgr_lang' ),
					),
				'public'			=>	true,
				'menu_icon'		=>	'dashicons-editor-kitchensink',
				'has_archive'	=>	true,
				'rewrite'		=>	array('slug' => 'mega_footer'),
				'supports'		=>	array('title','editor')
				)
			);
		}
		
		
		/*
		*	Remove 3rd party metaboxes
		*	on this CPT
		*/
		function hgr_remove_thrdparty_meta_boxes() {
			remove_meta_box( 'mymetabox_revslider_0', 'hgr_megafooter', 'normal' );
			remove_meta_box( 'eg-meta-box', 'hgr_megafooter', 'normal' );
		}
		
		
		/**
		* Add hgr_megafooter metaboxes function for pages
		* @since 1.0.0
		* Doc: https://codex.wordpress.org/Function_Reference/add_meta_box
		*/	
		function hgr_megafooter_metaboxes() {
			$screens = array( 'page' ); // Available on pages only
			foreach ( $screens as $screen ) {
				add_meta_box(
					'hgr_megafooter_metabox',					// $id
					__( 'MegaFooter Settings', 'hgr_lang' ),		// $title
					array($this,'hgr_megafooter_custom_box'),	// $callback
					$screen,									// $screen
					'side',										// $context
					'low'										// $priority
				);
			}
		}
	
		function hgr_megafooter_custom_box($post) {
			// Add an nonce field so we can check for it later
			wp_nonce_field( 'hgr_megafooter_custom_box', 'hgr_megafooter_custom_box_nonce' );
	
			// Get metaboxes values from database
			$hgr_megafooterID	=	get_post_meta( $post->ID, '_hgr_megafooterID', true );	// hgr_megafooter unique ID
			
			// Construct the metaboxes and print out
			
			// What Popup to be displayed on this page?
			echo '<div class="settBlock" style="margin-bottom:15px"><label for="hgr_megafooterID" style="width:170px;display:inline-block;height:30px;">';
			   esc_html_e( "MegaFooter for this page", 'hgr_lang' );
			echo '</label> ';
				echo '<select name="hgr_megafooterID" id="hgr_megafooterID">';
				
				$args = array(
					'post_type'		=>	'hgr_megafooter',
					'posts_per_page'=>	'99'
				 );
				$megafooters_array = get_posts( $args );
				
				if( !empty($megafooters_array) ) {
					echo '<option value="" '.(empty($hgr_megafooterID) ? 'selected = "selected"' : '').'>Default MegaFooter</option>';
					foreach ( $megafooters_array as $megafooter ) {
						setup_postdata( $megafooter );
						echo '<option value="'.$megafooter->ID.'" '.($hgr_megafooterID == $megafooter->ID ? 'selected = "selected"' : '').'>'.$megafooter->post_title.'</option>';
					}
					wp_reset_postdata();
				} else {
					echo '<option value="" selected="selected">No MegaFooter Available</option>';
				}
			echo '</select></div>';
		}
		
		
		function hgr_save_megafooter_data( $post_id ) {
			// Check if our nonce is set.
			if ( ! isset( $_POST['hgr_megafooter_custom_box_nonce'] ) ) {
				return $post_id;
			}
	
			$nonce = $_POST['hgr_megafooter_custom_box_nonce'];
	
			// Verify that the nonce is valid
			if ( ! wp_verify_nonce( $nonce, 'hgr_megafooter_custom_box' ) ) {
				return $post_id;
			}
	
			// If this is an autosave, our form has not been submitted, so we don't want to do anything
			if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
				//return $post_id;
			}
	
			// Check the user's permissions.
			if ( 'page' == $_POST['post_type'] ) {
				if ( ! current_user_can( 'edit_page', $post_id ) )
				return $post_id;
			} else {
				if ( ! current_user_can( 'edit_post', $post_id ) )
				return $post_id;
			}
			
			// OK to save data
			// Sanitize user input
			$hgr_megafooterID			= sanitize_text_field( $_POST['hgr_megafooterID'] );	
			
			// Update the meta field in the database
			update_post_meta( $post_id, '_hgr_megafooterID',	 $hgr_megafooterID );
		}
	}
	/*
		All good, fire up the plugin :)
	*/
	new HGR_MEGAFOOTER;
}