jQuery(document).ready(function() {
	jQuery('.hgr_advimage').each( function() { jQuery(this).hoverdir(); } );
});